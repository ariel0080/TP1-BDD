export enum TipoMovimiento {

  crear = 'Crear',
  agregar = 'Agregar Stock',
  sacar = 'Sacar Stock',
  desHabilitar = 'Borrado Lógico',
  habilitar = 'Revivir Producto'
}
