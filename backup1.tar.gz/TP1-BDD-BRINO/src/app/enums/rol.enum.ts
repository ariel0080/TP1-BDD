export enum Rol {
    Usuario = 'Usuario',
    Admin = 'Administrador'
  }
  