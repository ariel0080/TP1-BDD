export interface LocalI {
    nombre: string;
    direccion: string;
    activo: boolean;
  }
  