import { Local } from './local';

describe('Local', () => {
  it('should create an instance', () => {
    expect(new Local()).toBeTruthy();
  });
});
